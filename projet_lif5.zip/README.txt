##################################
# PROJET LIFAP5
# 2018/2019
##################################


==============================
* Etudiants
==============================
- HERVE Clément [p1615530]
- TEIXEIRA MAGALHAES Tiago [p141...]


==============================
* Description du projet
==============================

Ce projet consiste à réaliser un gestionnaire de débat, ie un forum sur lequel les gens peuvent
échanger des points de vue constructif.

